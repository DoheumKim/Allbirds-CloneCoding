import api from "./axiosInstance";

// 1. 상품 목록 가져오기 (필터/정렬 기능 추가)
// params 예시: { sort: 'recommend', category: '슬립온', size: 270 }
export async function fetchProducts(params) {
  // api.get의 두 번째 인자로 params를 넘기면 알아서 쿼리스트링(?key=value)으로 변환됨
  const res = await api.get("/api/products", { params });
  return res.data; 
}

// 2. 상품 상세 정보 가져오기 (상세 페이지용)
export async function fetchProductDetail(id) {
  const res = await api.get(`/api/products/${id}`);
  return res.data;
}

// 3. 상품 리뷰 목록 가져오기
export async function fetchReviews(id) {
  const res = await api.get(`/api/products/${id}/reviews`);
  return res.data;
}

// 4. 상품 리뷰 등록하기 (로그인 필수)
export async function createReview(id, reviewData) {
  // reviewData: { rating: 5, comment: "좋아요" }
  const res = await api.post(`/api/products/${id}/reviews`, reviewData);
  return res.data;
}

// 5. 상품 데이터 동기화 (프론트 -> 서버 DB)
export async function syncProductsFromClient(products) {
  const res = await api.post("/api/products/sync-from-client", products);
  return res.data;
}