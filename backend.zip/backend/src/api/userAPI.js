// src/api/userAPI.js
import api from "./axiosInstance";

// 1. 회원가입
export async function registerUser(userData) {
  // userData 예시: { loginName: "id", password: "pw", displayName: "name" }
  const res = await api.post("/api/users/register", userData);
  return res.data;
}

// 2. 로그인
export async function loginUser(loginName, password) {
  const res = await api.post("/api/users/login", { loginName, password });
  return res.data;
}

// 3. 내 정보 조회 (새로고침 시 로그인 유지 확인용)
export async function getMe() {
  const res = await api.get("/api/users/me");
  return res.data;
}

[cite_start]// 4. 내 주문 내역 조회 (마이페이지용)
// 주문 내역에는 totalPrice, items(상품명, 수량, 가격), 결제일 등이 포함됨
export async function fetchMyOrders() {
  const res = await api.get("/api/orders/my");
  return res.data;
}