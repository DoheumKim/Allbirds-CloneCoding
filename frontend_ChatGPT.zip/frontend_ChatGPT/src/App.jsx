import React, { useState, useMemo } from "react";
import Header from "./components/Header";
import HeroBanner from "./components/HeroBanner";
import FilterBar from "./components/FilterBar";
import SidebarFilters from "./components/SidebarFilters";
import ProductGrid from "./components/ProductGrid";
import { products } from "./data/products";

/**
 * 요구사항:
 * - '기능', '모델' 탭 제거 (Header에서 처리)
 * - 카테고리 4개(신제품/라이프스타일/세일/슬립온)만 필터링
 * - 상단 버튼 클릭 시 해당 카테고리 제품만 표시 (React state 사용)
 * - '할인 전체: 실시간 인기 항목' 섹션은 완전히 제거 (구현 안함)
 */
export default function App() {
  const [activeCategory, setActiveCategory] = useState("전체");

  const filteredProducts = useMemo(() => {
    if (activeCategory === "전체") return products;
    return products.filter((p) => p.categories.includes(activeCategory));
  }, [activeCategory]);

  return (
    <div className="app">
      <Header />
      <main>
        <HeroBanner />

        <section className="content">
          <FilterBar
            activeCategory={activeCategory}
            onChangeCategory={setActiveCategory}
          />

          <div className="content__body">
            <SidebarFilters />
            <ProductGrid products={filteredProducts} />
          </div>
        </section>
      </main>
    </div>
  );
}
