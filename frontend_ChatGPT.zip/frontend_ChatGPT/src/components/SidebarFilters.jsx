import React from "react";

const sizes = [
  "250",
  "255",
  "260",
  "265",
  "270",
  "275",
  "280",
  "285",
  "290",
  "295",
  "300",
  "305",
  "310",
  "315",
  "320",
];

const materials = [
  "가볍고 시원한 tree",
  "면",
  "부드럽고 따뜻한 wool",
  "캔버스",
  "플라스틱 제로 식물성 가죽",
];

const functions = [
  "비즈니스",
  "캐주얼",
  "가벼운 산책",
  "러닝",
  "발수",
  "슬립온",
  "트레이닝",
  "클래식 스니커즈",
  "라이프스타일",
  "초경량",
];

export default function SidebarFilters() {
  return (
    <aside className="sidebar">
      <div className="sidebar__section">
        <h3 className="sidebar__title">사이즈</h3>
        <div className="sidebar__size-grid">
          {sizes.map((size) => (
            <button key={size} type="button" className="size-btn">
              {size}
            </button>
          ))}
        </div>
      </div>

      <div className="sidebar__section">
        <h3 className="sidebar__title">소재</h3>
        <ul className="sidebar__checkbox-list">
          {materials.map((m) => (
            <li key={m} className="sidebar__checkbox-item">
              <label>
                <input type="checkbox" />
                <span>{m}</span>
              </label>
            </li>
          ))}
        </ul>
      </div>

      <div className="sidebar__section">
        <h3 className="sidebar__title">기능</h3>
        <ul className="sidebar__checkbox-list">
          {functions.map((f) => (
            <li key={f} className="sidebar__checkbox-item">
              <label>
                <input type="checkbox" />
                <span>{f}</span>
              </label>
            </li>
          ))}
        </ul>
      </div>
    </aside>
  );
}
