import React from "react";
import ProductCard from "./ProductCard";

export default function ProductGrid({ products }) {
  return (
    <section className="product-grid">
      <div className="product-grid__count">
        {products.length}개 제품
      </div>
      <div className="product-grid__list">
        {products.map((p) => (
          <ProductCard key={p.id} {...p} />
        ))}
      </div>
    </section>
  );
}
