import React from "react";
import { CATEGORIES } from "../data/products";

export default function FilterBar({ activeCategory, onChangeCategory }) {
  return (
    <div className="filter-bar">
      <div className="filter-bar__tabs">
        {/* 전체 보기 버튼 (선택사항) */}
        <button
          className={
            activeCategory === "전체"
              ? "filter-bar__tab filter-bar__tab--active"
              : "filter-bar__tab"
          }
          type="button"
          onClick={() => onChangeCategory("전체")}
        >
          남성 할인 전체
        </button>

        {CATEGORIES.map((cat) => (
          <button
            key={cat}
            type="button"
            className={
              activeCategory === cat
                ? "filter-bar__tab filter-bar__tab--active"
                : "filter-bar__tab"
            }
            onClick={() => onChangeCategory(cat)}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* 정렬/필터 버튼 (우측 아이콘만) */}
      <button className="filter-bar__sort-btn" type="button">
        <span className="filter-bar__sort-icon" />
      </button>
    </div>
  );
}
