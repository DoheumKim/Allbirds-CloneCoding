import React from "react";

export default function Header() {
  return (
    <>
      {/* 상단 블랙 정보 바 */}
      <div className="top-banner">
        <div className="top-banner__text">
          BLACK FRIDAY SALE! 이번주 세일 종료. 보상 연장
        </div>
        <div className="top-banner__sub">
          *지금 주문 시, 3 영업일 이내 순차 출고 (주말, 휴일 제외)
        </div>
      </div>

      {/* 메인 헤더 */}
      <header className="header">
        <div className="header__inner">
          <a href="#" className="header__logo">
            allbirds
          </a>

          {/* 요구사항: 기능 / 모델 탭 제거된 내비게이션 */}
          <nav className="header__nav">
            <a href="#" className="header__nav-item">
              슈퍼 블랙 프라이데이
            </a>
            <a href="#" className="header__nav-item">
              매장 위치
            </a>
            <a href="#" className="header__nav-item">
              지속 가능성
            </a>
          </nav>

          <div className="header__actions">
            <button className="header__icon-btn" aria-label="검색">
              🔍
            </button>
            <button className="header__icon-btn" aria-label="내 계정">
              👤
            </button>
            <button className="header__icon-btn header__cart" aria-label="장바구니">
              🛍
              <span className="header__cart-count">0</span>
            </button>
          </div>
        </div>
      </header>
    </>
  );
}
