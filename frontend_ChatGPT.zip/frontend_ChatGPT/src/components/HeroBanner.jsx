import React from "react";

export default function HeroBanner() {
  return (
    <section className="hero">
      <div className="hero__left-circle" />
      <div className="hero__content">
        <p className="hero__kicker">BLACK FRIDAY SALE: 할인 전체</p>
        <h1 className="hero__title">이번주 세일이 종료됩니다.</h1>
      </div>
      <div className="hero__bg-text">
        <span>UP TO</span>
        <span>50% OFF</span>
      </div>
    </section>
  );
}
