import React from "react";

function formatPrice(price) {
  return price.toLocaleString("ko-KR");
}

export default function ProductCard({
  name,
  tags,
  discountPercent,
  price,
  originalPrice,
  onlineOnly,
}) {
  return (
    <article className="product-card">
      <div className="product-card__image-wrapper">
        {/* 실제 이미지 대신 회색 박스 사용 */}
        <div className="product-card__image-placeholder" />
        <div className="product-card__discount-badge">
          ~{discountPercent}%
        </div>
      </div>

      <div className="product-card__content">
        <h3 className="product-card__name">{name}</h3>
        <p className="product-card__tags">{tags.join(", ")}</p>

        <div className="product-card__price-row">
          <span className="product-card__discount-text">
            {discountPercent}%{" "}
            <span className="product-card__price">
              ₩{formatPrice(price)}
            </span>
          </span>
          <span className="product-card__original-price">
            ₩{formatPrice(originalPrice)}
          </span>
        </div>

        {onlineOnly && (
          <div className="product-card__online-only">ONLINE EXCLUSIVE</div>
        )}
      </div>
    </article>
  );
}
