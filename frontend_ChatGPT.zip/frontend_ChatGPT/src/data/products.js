// 필터용 카테고리 (요구사항의 4가지)
export const CATEGORIES = ["신제품", "라이프스타일", "세일", "슬립온"];

/**
 * 실제 API 대신 하드코딩된 상품 데이터
 * categories 배열에 위 CATEGORIES 중 여러 개가 들어갈 수 있다.
 */
export const products = [
  {
    id: 1,
    name: "남성 울 러너 NZ",
    tags: ["캐주얼", "비즈니스", "클래식 스니커즈"],
    discountPercent: 30,
    price: 119000,
    originalPrice: 170000,
    categories: ["라이프스타일", "세일"],
    onlineOnly: false,
  },
  {
    id: 2,
    name: "남성 트리 러너",
    tags: ["캐주얼", "비즈니스", "클래식 스니커즈"],
    discountPercent: 30,
    price: 115000,
    originalPrice: 165000,
    categories: ["라이프스타일", "세일"],
    onlineOnly: false,
  },
  {
    id: 3,
    name: "남성 트리 대셔 2",
    tags: ["러닝", "라이프스타일", "애슬레저"],
    discountPercent: 50,
    price: 98000,
    originalPrice: 180000,
    categories: ["라이프스타일", "세일"],
    onlineOnly: false,
  },
  {
    id: 4,
    name: "남성 트리 러너 (화이트)",
    tags: ["신제품", "러닝", "라이프스타일"],
    discountPercent: 20,
    price: 135000,
    originalPrice: 169000,
    categories: ["신제품", "라이프스타일"],
    onlineOnly: true,
  },
  {
    id: 5,
    name: "남성 트리 슬립온",
    tags: ["슬립온", "라이프스타일"],
    discountPercent: 30,
    price: 99000,
    originalPrice: 149000,
    categories: ["슬립온", "라이프스타일", "세일"],
    onlineOnly: true,
  },
  {
    id: 6,
    name: "남성 라운지 슬립온",
    tags: ["슬립온", "초경량"],
    discountPercent: 25,
    price: 89000,
    originalPrice: 119000,
    categories: ["슬립온", "라이프스타일", "세일"],
    onlineOnly: false,
  },
  {
    id: 7,
    name: "남성 울 러너 (신제품 컬러)",
    tags: ["신제품", "클래식 스니커즈"],
    discountPercent: 10,
    price: 149000,
    originalPrice: 165000,
    categories: ["신제품", "라이프스타일"],
    onlineOnly: false,
  },
  {
    id: 8,
    name: "남성 트리 러너 (세일)",
    tags: ["러닝", "세일"],
    discountPercent: 40,
    price: 99000,
    originalPrice: 165000,
    categories: ["세일"],
    onlineOnly: false,
  },
];
